package Pertemuan8UTS;

public interface AttackStrategy {
    int computeDamage(Character self, Character target);
}